#!/bin/bash
# Bash script to setup basic configs of HF 2013 VMs

if [[ $(/usr/bin/id -u) -ne 0 ]]; then
    echo "Not running as root."
    exit
fi

SCRIPT_DIR=`pwd`
echo 'Execution folder : '$SCRIPT_DIR

###########################Color Formating##############################
TEXT_COLOR="[38;05;105m"
DEFAULT_COLOR="[38;05;015m"
SUCCESS_COLOR="[38;05;125m"
RED_COLOR="[31;01m"
########################################################################

###########################Main script##############################
# Install some packages
echo $TEXT_COLOR"Installing some packages  - OpenVPN and family"$DEFAULT_COLOR
#####bash /Project/setupVM/sh/installOpenVPN.sh

if [ $? -ne 0 ]; then
	echo $ERROR_COLOR''Error when installing OpenVPN packages''$DEFAULT_COLOR
	exit 1
fi

echo $SUCCESS_COLOR''Installation of OpenVPN packages succesfull''$DEFAULT_COLOR
echo $TEXT_COLOR''Copying easy-rsa folder''$DEFAULT_COLOR
if [[ ! -d "/etc/openvpn/easy-rsa" ]];then
	mkdir /etc/openvpn/easy-rsa
	/bin/cp -rfn /usr/share/doc/openvpn/examples/easy-rsa/2.0/* /etc/openvpn/easy-rsa
fi
echo $TEXT_COLOR''Copying vars to easy-rsa aka Default key generation parameters''$DEFAULT_COLOR
/bin/cp -rfn files/vars /etc/openvpn/easy-rsa
cd /etc/openvpn/easy-rsa
source ./vars

echo $TEXT_COLOR''Cleaning current existing key''$DEFAULT_COLOR
./clean-all > /dev/null

echo $TEXT_COLOR''Creating key server - Hackfest''$DEFAULT_COLOR
./build-key-server hackfestvpn > /dev/null
echo $RED_COLOR''Warning! You gonna be prompted by the few next commands. Just press enter utill the end''$DEFAULT_COLOR
./build-ca
./build-key-server hackfestvpn

echo $TEXT_COLOR''Creating team keys''$DEFAULT_COLOR
./build-key team1
./build-key team2
./build-key team3
./build-key team4
./build-key team5
./build-key team6
./build-key team7
./build-key team8
./build-dh
#openvpn --genkey --secret keys/static.key

echo $TEXT_COLOR''Copying keys to the script file folder for further utilisation''$DEFAULT_COLOR
/bin/cp -rfn keys/* $SCRIPT_DIR/files/

echo $SUCCESS_COLOR''Configuration of OpenVPN packages succesfull''$DEFAULT_COLOR
exit 0
